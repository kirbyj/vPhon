# -*- coding: utf-8 -*-
name = "rules"
from .north import *
from .central import *
from .south import *
