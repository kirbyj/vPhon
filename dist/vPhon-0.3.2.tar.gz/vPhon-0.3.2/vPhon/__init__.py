# -*- coding: utf-8 -*-
name = "vPhon"
from .rules.north import *
from .rules.central import *
from .rules.south import *
